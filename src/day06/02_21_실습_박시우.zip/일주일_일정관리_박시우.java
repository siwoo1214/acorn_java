package day06;

import java.util.Scanner;

public class 일주일_일정관리_박시우 {
	public static void main(String[] args) {
		String[][] schedule = new String[7][7];
		Scanner sc = new Scanner(System.in);
		
		int[] idx_each = new int[7];
		
		loop: while(true) {
			System.out.print("일정을 추가하려면 '요일'을 입력 후 '일정'을 입력하고 \n조회나 종료를 하려면 '조회' 또는 '종료' 를 입력하세요");
			String day = sc.next();
			
			switch(day) {
			case "월":
				schedule[0][idx_each[0]] = sc.next();
				idx_each[0]++;
				break;
			case "화":
				schedule[1][idx_each[1]] = sc.next();
				idx_each[1]++;
				break;
			case "수":
				schedule[2][idx_each[2]] = sc.next();
				idx_each[2]++;
				break;
			case "목":
				schedule[3][idx_each[3]] = sc.next();
				idx_each[3]++;
				break;
			case "금":
				schedule[4][idx_each[4]] = sc.next();
				idx_each[4]++;
				break;
			case "토":
				schedule[5][idx_each[5]] = sc.next();
				idx_each[5]++;
				break;
			case "일":
				schedule[6][idx_each[6]] = sc.next();
				idx_each[6]++;
				break;
			case "조회":
				System.err.print("월요일부터 일요일까지 1~7의 숫자로 조회할 날짜를 입력하세요");
				int when = sc.nextInt();
				for(int i=0; i<idx_each[when-1]; i++) {
					System.out.println(i+". "+schedule[when-1][i]);
				}
				break;
			case "종료":
				System.out.println("종료합니다");
				break loop;
			}
		}
	}
}
